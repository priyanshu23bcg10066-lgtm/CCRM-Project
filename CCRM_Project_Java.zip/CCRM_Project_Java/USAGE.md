# Usage

Place sample CSVs under `test-data/` (provided). Run the CLI and choose menu options.

Sample files:
- test-data/students.csv
- test-data/courses.csv

Exports will be created under `exports/`. Backups under `backups/`.
