package edu.ccrm.util;

public class Validator {
}